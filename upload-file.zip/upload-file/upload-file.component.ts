import { Component, OnInit } from '@angular/core';
import { FileHandle } from './dragDrop.directive';
import { Observable } from 'rxjs';
import { UserService } from 'src/app/core';
import { FileHelper } from './file.helper';
@Component({
  selector: 'upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {
  files: FileHandle[] = [];
  url:any=[];
  fileMap:File[]=[];
  uploadFiles:FileHelper;
  constructor(private userService: UserService) { }

  ngOnInit() {
  }


 

  filesDropped(files: FileHandle[]): void {
    this.files = files;
  console.log(files.splice);
  }

  upload(files:File[]): void {
    //get image upload file obj;
    console.log(files.length+"uploading...");

    this.userService.uploadfile(files);
    console.log("testing");
   }


   onSelectFile(event){
     if(event.target.files && event.target.files.length>0){
       this.fileMap=event.target.files;
       var reader=new FileReader();
       for(let fileUrl of this.fileMap){
         reader.readAsDataURL(fileUrl);
         this.uploadFiles.name=fileUrl.name;
           this.uploadFiles.type=fileUrl.type;
           this.uploadFiles.size=fileUrl.size;
         reader.onload=(event)=>{
           this.url.push(reader.result);
           
           //this.uploadFiles.url=reader.result;
         }
       }
     }
     console.log(this.uploadFiles);
   }
}

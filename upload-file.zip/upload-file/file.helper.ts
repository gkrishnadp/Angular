

  export class FileHelper{
    file: File;
    url: string;
    name:string;
    type:string;
    size:number;

    
  }
﻿interface Caravan {
    rooms: number;
}

let caravan: Caravan;

if (caravan && caravan.rooms > 5) {
    //...
}
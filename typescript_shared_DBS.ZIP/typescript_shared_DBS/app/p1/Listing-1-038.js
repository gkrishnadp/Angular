var caravan;
if (caravan && caravan.rooms > 5) {
    //...
}

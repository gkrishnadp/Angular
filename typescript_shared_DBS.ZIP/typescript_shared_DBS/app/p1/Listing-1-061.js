{
    var shortAddNumbers = function (a, b) { return a + b; };
    var mediumAddNumbers = function (a, b) {
        return a + b;
    };
    var longAddNumbers = function (a, b) {
        return a + b;
    };
}

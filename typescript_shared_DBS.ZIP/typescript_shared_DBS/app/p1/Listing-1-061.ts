﻿{
    const shortAddNumbers = (a: number, b: number) => a + b;

    const mediumAddNumbers = (a: number, b: number) => {
        return a + b;
    }

    const longAddNumbers = function (a: number, b: number) {
        return a + b;
    }
}
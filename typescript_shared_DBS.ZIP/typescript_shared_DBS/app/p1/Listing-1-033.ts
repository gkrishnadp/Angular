﻿{
    const str: string = '5';

    // 5: number 
    const num = +str;

    // -5: number 
    const negative = -str;
}
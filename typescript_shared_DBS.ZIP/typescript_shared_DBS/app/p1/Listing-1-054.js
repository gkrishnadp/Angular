var Listing_1_54;
(function (Listing_1_54) {
    function getAverage(a, b, c) {
        var total = a + b + c;
        var average = total / 3;
        return 'The average is ' + average;
    }
    var result = getAverage(4, 3, 8); // 'The average is 5'
})(Listing_1_54 || (Listing_1_54 = {}));

{
    var isValid_1 = true;
    // Conditional operator
    var message_1 = isValid_1 ? 'Okay' : 'Failed';
}

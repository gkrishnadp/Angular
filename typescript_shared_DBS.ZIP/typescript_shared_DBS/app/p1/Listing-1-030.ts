﻿let counter = 0;

do {
    ++counter;
} while (counter < 10);

// 10
alert(counter);
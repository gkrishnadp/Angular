{
    var str_1 = '5';
    // 5: number 
    var num_1 = +str_1;
    // -5: number 
    var negative = -str_1;
}

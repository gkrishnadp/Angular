{
    var triangles = [1, 3, 6];
    var first = void 0, second = void 0, third = void 0, fourth = void 0;
    // Destructuring past available values
    first = triangles[0], second = triangles[1], _a = triangles[2], third = _a === void 0 ? -1 : _a, _b = triangles[3], fourth = _b === void 0 ? -1 : _b;
    // 6
    console.log(third);
    // -1
    console.log(fourth);
}
var _a, _b;

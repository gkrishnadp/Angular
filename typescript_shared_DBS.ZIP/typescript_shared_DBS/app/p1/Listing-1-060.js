var Example = /** @class */ (function () {
    function Example() {
    }
    Example.prototype.getElementsByTagName = function (name) {
        return document.getElementsByTagName(name);
    };
    return Example;
}());

{
    var makeName = function (f, l) { return ({ first: f, last: l }); };
}

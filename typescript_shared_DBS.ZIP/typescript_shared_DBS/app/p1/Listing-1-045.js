{
    var highSchool = { school: 'Central High', team: 'Centaurs' };
    // Object destructuring
    var s = highSchool.school, t = highSchool.team;
    // 'Central High'
    console.log(s);
    // 'Centaurs'
    console.log(t);
}

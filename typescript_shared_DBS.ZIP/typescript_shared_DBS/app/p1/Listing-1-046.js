{
    var highSchool = { school: 'Central High', team: 'Centaurs' };
    // Auto-unpacking
    var school = highSchool.school, team = highSchool.team;
    // 'Central High'
    console.log(school);
    // 'Centaurs'
    console.log(team);
}

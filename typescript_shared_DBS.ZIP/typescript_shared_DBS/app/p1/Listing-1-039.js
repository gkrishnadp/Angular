var isValid = true;
var message;
// Long-hand equivalent
if (isValid) {
    message = 'Okay';
}
else {
    message = 'Failed';
}

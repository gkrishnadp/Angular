﻿{
    const highSchool = { school: 'Central High', team: 'Centaurs' };

    // Auto-unpacking
    const { school, team } = highSchool;

    // 'Central High'
    console.log(school);

    // 'Centaurs'
    console.log(team);
}
﻿document.getElementById('target').onclick = function () { 
	clickCounter.registerClick();
};
{
    var triangles = [1, 3, 6, 10, 15, 21];
    // Skipping third item
    var first = triangles[0], second = triangles[1], fourth = triangles[3];
    // 1
    console.log(first);
    // 3
    console.log(second);
    // [10]
    console.log(fourth);
}

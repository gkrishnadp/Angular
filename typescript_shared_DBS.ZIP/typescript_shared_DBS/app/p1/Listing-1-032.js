// 6: number 
var num = 5 + 1;
// '51': string 
var str = 5 + '1';

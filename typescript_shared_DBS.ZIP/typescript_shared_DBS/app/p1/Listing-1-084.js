var Listing_1_84;
(function (Listing_1_84) {
    var Display = /** @class */ (function () {
        function Display() {
        }
        return Display;
    }());
    var display = new Display();
    // false
    var hasName = 'name' in display;
})(Listing_1_84 || (Listing_1_84 = {}));

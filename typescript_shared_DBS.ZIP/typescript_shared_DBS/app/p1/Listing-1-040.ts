﻿{
    const isValid = true;

    // Conditional operator
    const message = isValid ? 'Okay' : 'Failed';
}
{
    var triangles = [1, 3, 6];
    // Destructuring past available values
    var first = triangles[0], second = triangles[1], third = triangles[2], fourth = triangles[3];
    // undefined
    console.log(fourth);
}

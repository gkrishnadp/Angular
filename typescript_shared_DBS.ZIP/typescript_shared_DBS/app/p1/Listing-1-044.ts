﻿{
    let a = 3;

    let b = 5;

    // Swapping
    [a, b] = [b, a];

    // 5
    console.log(a);

    // 3
    console.log(b);
}
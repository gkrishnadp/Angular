﻿{
    const makeName = (f: string, l: string) => ({ first: f, last: l });
}
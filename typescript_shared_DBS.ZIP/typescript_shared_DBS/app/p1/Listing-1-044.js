{
    var a = 3;
    var b = 5;
    // Swapping
    _a = [b, a], a = _a[0], b = _a[1];
    // 5
    console.log(a);
    // 3
    console.log(b);
}
var _a;

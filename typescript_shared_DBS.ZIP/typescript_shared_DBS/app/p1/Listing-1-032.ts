﻿// 6: number 
const num = 5 + 1;

// '51': string 
const str = 5 + '1';